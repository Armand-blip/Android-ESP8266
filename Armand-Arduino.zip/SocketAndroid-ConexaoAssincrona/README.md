# SocketAndroid
Socket Bridge between Android and ESP8266 

This code it's the implementation of ideias in my Article in Medium, about TCP Comunication between a ESP8266 NodeMCU and a Android App 

Link for article: https://medium.com/@czarantoniodesouza/construindo-uma-ponte-tcp-entre-um-app-android-e-uma-esp8266-1c56451c7ce1#.rbq3hki4k
