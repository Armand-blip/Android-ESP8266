package com.connect.socketsandroid;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.connect.socketsandroid.net.RepeatListener;
import com.connect.socketsandroid.interfaces.ITcpListener;
import com.connect.socketsandroid.net.AssincronnousConnectType;
import com.connect.socketsandroid.net.BridgeConnectType;
import com.connect.socketsandroid.net.ConnectBridgeAsyncTask;
import com.connect.socketsandroid.net.AsyncSendSocketTask;
import com.connect.socketsandroid.net.NetParameters;
import com.connect.socketsandroid.net.TCPBridge;
import com.connect.socketsandroid.net.WithOutBridgeConnectType;

import android.view.View.OnClickListener;
import java.util.Random;

public class MainActivity extends Activity implements ITcpListener {
    private AsyncSendSocketTask sendSocketTask;
    private AssincronnousConnectType assTask;
    private BridgeConnectType bridgeConnectType;
    private Random numRand;
    private Button btnSend;
    private TextView txtExplicacao;
    private TextView txtResultado;
    private TCPBridge principalBridge;
    private Handler handTmConnect;
    private int contConnectedTry = 0;
    private boolean isBridgeConnected = false;
    private Button ONN;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ONN = (Button) findViewById(R.id.ON);


        numRand = new Random();
        txtExplicacao = (TextView) findViewById(R.id.txtExplicacao);
        txtResultado = (TextView) findViewById(R.id.txtResult);
        btnSend = (Button) findViewById(R.id.btnEnviar);
        ONN=(Button) findViewById(R.id.ON);
    }

    private void initTimerToConnect() {
        txtExplicacao.setText(getResources().getString(R.string.wait));
        // Start a timer to try connect
        handTmConnect = new Handler();
        handTmConnect.removeCallbacks(vh_tryConnectAtESP8266);
        handTmConnect.postDelayed(vh_tryConnectAtESP8266, NetParameters.intervalToTry);
    }

    private Runnable vh_tryConnectAtESP8266 = new Runnable() {
        public void run() {
            makeTheBrideAsync();
        }
    };

    private void makeTheBrideAsync() {
        new ConnectBridgeAsyncTask(this, new TCPBridge()).execute();
    }

    public void sendSocket(View v) {
        if (!isBridgeConnected) {
            initTimerToConnect();
        } else {
            // Situação nº 1, explicada no post
            // Utilizando ReadLine
            //sendSocketTask=new AsyncSendSocketTask(this, new WithOutBridgeConnectType());
            //sendSocketTask.execute();
            // -------------------------------------------------------------------------------------
            // Situação nº 2, explicada no post
            // Utilizando Sockets Assíncronos
            //sendSocketTask = new AsyncSendSocketTask(this, new AssincronnousConnectType());
            //sendSocketTask.execute();
            // -------------------------------------------------------------------------------------
            // Situação correta
            // Esta é a situação que me gerou melhores resultados. Um socket que fica
            // conectado de forma constante e que recebe os dados em forma de bytes.

            sendSocketTask = new AsyncSendSocketTask(this, new BridgeConnectType(principalBridge));
            sendSocketTask.execute();
        }
    }




    /**********************************************************************************************/
    /* Implementation of methods */
    @Override
    public void onBridgeIsCreated(TCPBridge vo_Bridge) {
        principalBridge = vo_Bridge;
        handTmConnect.removeCallbacks(vh_tryConnectAtESP8266);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //txtExplicacao.setText(getResources().getString(R.string.clickToSend));
                //btnSend.setText(getResources().getString(R.string.Send));
                ONN.setText(getResources().getString(R.string.clickToON));
                isBridgeConnected = true;

            }
        });
    }

    @Override
    public void onExceptionOcorred(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                txtExplicacao.setText(message);
            }
        });
    }

    @Override
    public void onFailToConnect() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                if (contConnectedTry < NetParameters.numberToTryConnect) {
                    handTmConnect.postDelayed(vh_tryConnectAtESP8266, NetParameters.intervalToTry);
                    contConnectedTry++;
                    txtExplicacao.setText(getResources().getString(R.string.clickToON) + " - " + contConnectedTry);
                } else {
                    contConnectedTry = 0;
                    txtExplicacao.setText(getResources().getString(R.string.endOfTry));
                    handTmConnect.removeCallbacks(vh_tryConnectAtESP8266);
                }
            }
        });
    }

    @Override
    public void onTCPMessageRecieved(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // if the message is equal, the random number show the difference
                txtResultado.setText(numRand.nextDouble() + message);
            }
        });
    }
    /**********************************************************************************************/
/*
    private void timerConnection()
    {
        txtExplicacao.setText(getResources().getString(R.string.wait));
        // Start a timer to try connect
        handTmConnect = new Handler();
        handTmConnect.removeCallbacks(vh_tryConnectAtESP8266);
        handTmConnect.postDelayed(vh_tryConnectAtESP8266, NetParameters.intervalToTry);
    }

    @Override
    public void onClickOn()
    {
        if(socket != null)
        {
            timerConnection();
            try {
                serverAddr = InetAddress.getByName(NetParameters.ipESP8266);
            } catch (UnknownHostException e) {
                e.printStackTrace();
            }

            // Socket.disconnect();
        }
        else
        {
            //socket = new Socket(serverAddr,NetParameters.portaESP8266);
            socket.createSocket();
            socket.connect();
        }
        });



ONN.OnTouchListener(new View.OnTouchListener() {
    @Override
    public boolean onTouch(View ONN, MotionEvent event) {
        switch(event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                // PRESSED
                // You can call a thread here which will keep increasing the time
                return true;
            case MotionEvent.ACTION_UP:
                // RELEASED
                // Stop the thread here
                return true;
        }
        return false;
    }
});
*//*
private Runnable handlerRunnable = new Runnable() {
    @Override
    public void run() {
        handler.postDelayed(this, normalInterval);
        clickListener.onClick(downView);
    }
};
    private View downView;


    public void MainActivity(int initialInterval, int normalInterval,
                          OnClickListener clickListener) {
        if (clickListener == null)
            throw new IllegalArgumentException("null runnable");
        if (initialInterval < 0 || normalInterval < 0)
            throw new IllegalArgumentException("negative interval");

        this.initialInterval = initialInterval;
        this.normalInterval = normalInterval;
        this.clickListener = clickListener;
    }
    public boolean onTouch(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case MotionEvent.ACTION_DOWN:
                handler.removeCallbacks(handlerRunnable);
                handler.postDelayed(handlerRunnable, initialInterval);
                downView = view;
                downView.setPressed(true);
                clickListener.onClick(view);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(handlerRunnable);
                downView.setPressed(false);
                downView = null;
                return true;
        }

        return false;
    }*/
    /**********************************************************************************************/
}