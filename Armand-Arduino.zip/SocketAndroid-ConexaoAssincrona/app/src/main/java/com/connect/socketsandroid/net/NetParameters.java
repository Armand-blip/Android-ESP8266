package com.connect.socketsandroid.net;

/**
 * Created by cezar on 2/6/17.
 */

public class NetParameters
{
    public static String ipESP8266 = "192.168.68.88";
    public static int portaESP8266 = 80;
    public static int sizeOfResponse = 17;
    public static int numberToTryConnect = 3;
    public static int intervalToTry = 1000;
}
