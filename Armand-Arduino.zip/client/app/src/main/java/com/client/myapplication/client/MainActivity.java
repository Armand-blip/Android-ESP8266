package com.client.myapplication.client;
import android.os.*;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View.OnTouchListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import android.os.AsyncTask;
@SuppressLint("SetTextI18n")
public class MainActivity extends AppCompatActivity {

    Thread Thread1 = null;

    EditText etIP, etPort;
    TextView tvMessages;

    EditText etMessage;
    Button btnSendUp;
    Button btnSendDown;

    String SERVER_IP;
    int SERVER_PORT;


    private PrintWriter output;
    private BufferedReader input;

    private String m_StrUP ="UP";
    private String m_StrDOWN ="DOWN";
    Th3Values m_valUp;
    Th3Values m_valDown;
    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etIP = findViewById(R.id.etIP);
        etPort = findViewById(R.id.etPort);

        etIP.setText("192.168.68.88");
        etPort.setText("80");

        tvMessages = findViewById(R.id.tvMessages);

        btnSendUp = findViewById(R.id.btnSend);
        m_valUp = new Th3Values();

        btnSendDown = findViewById(R.id.btnSend2);
        m_valDown = new Th3Values();

        Button btnConnect = findViewById(R.id.btnConnect);
        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvMessages.setText("");
                SERVER_IP = etIP.getText().toString().trim();
                SERVER_PORT = Integer.parseInt(etPort.getText().toString().trim());
                Thread1 = new Thread(new Thread1());
                Thread1.start();
            }
        });


        btnSendUp.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Thread a1=new Thread(new Thread3(m_valUp));
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                            m_valUp.message = m_StrUP;
                            m_valUp.bexit = false;
                            a1.start();
                        return true;
                    case MotionEvent.ACTION_UP:
                        m_valUp.bexit = true;
                        //pressedUp = false;
                        return true;
                }
                return false;
            }
        });

        btnSendDown.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Thread a=new Thread(new Thread3(m_valDown));
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        m_valDown.bexit=false;
                        m_valDown.message= m_StrDOWN;
                        a.start();
                        return true;
                    case MotionEvent.ACTION_UP:
                        m_valDown.bexit = true;
                        //pressedUp = false;
                        return true;
                }
                return false;
            }
        });



    }//OnCreate


    class Thread1 implements Runnable {

        public void run() {
            Socket socket;
            try {
                socket = new Socket(SERVER_IP, SERVER_PORT);

                output = new PrintWriter(socket.getOutputStream());
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        tvMessages.setText("Connected\n");
                    }
                });
                new Thread(new Thread2()).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    class Thread2 implements Runnable {
        @Override
        public void run() {
            while (true) {
                try {
                    final String message = input.readLine();
                    if (message != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvMessages.append("server: " + message + "\n");
                            }
                        });
                    } else {
                        Thread1 = new Thread(new Thread1());
                        Thread1.start();
                        return;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    class Thread3 implements Runnable {
        Th3Values LocData;
        Thread3(Th3Values Data) {
            LocData = Data;
        }
        @Override
        public void run() {
            while(!LocData.bexit){
                output.write(LocData.message);
                output.flush();

                try {
                    Thread.sleep(300);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        }
    } //Thread3

    class Th3Values {
        public String message;
        public boolean bexit;
    }
}